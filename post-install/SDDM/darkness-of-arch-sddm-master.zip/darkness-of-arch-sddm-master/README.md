# Darkness Of Arch Theme

An animated sddm theme with music

# Installation

Download or clone this repo into
    
    /usr/share/sddm/themes

# You can test it with

    sddm-greeter --test --theme /usr/share/sddm/themes/darkness-of-arch-sddm

# You can change the files

Logo:

    resources/logo.png

Background image:

    background.png
    
The particles:

    resources/lightparticle.png
    
The background music:

    resources/bgm.ogg
    
# Screenshot
    
![screenshot](screenshot.jpg)
